var selectedRow = null;
var dataBase = []
//dataBase = JSON.parse(localStorage.getItem("pastRecords"));

function onFormSubmit() {
    if (true) {
        var formData = readFormData();
        if (selectedRow == null) {
            insertNewRecord(formData);
        } else {
            updateRecord(formData);
        }
    }
}
function readFormData() {
    var formData = {};
    formData["firstName"] = document.getElementById("firstName").value;
    formData["lastName"] = document.getElementById("lastName").value;
    formData["email"] = document.getElementById("email").value;
    formData["address"] = document.getElementById("address").value;
    console.log(formData)
    dataBase.push(formData);
    localStorage.setItem("pastRecords", JSON.stringify(dataBase));
    return formData

}

function insertNewRecord(data) {
    var table = document.getElementById("employeeList").getElementsByTagName('tbody')[0];
    var newRecord = table.insertRow(table.length);
    cell1 = newRecord.insertCell(0);
    cell1.innerHTML = data.firstName;
    cell2 = newRecord.insertCell(1);
    cell2.innerHTML = data.lastName
    cell3 = newRecord.insertCell(2);
    cell3.innerHTML = data.email
    cell4 = newRecord.insertCell(3);
    cell4.innerHTML = data.address
    cell6 = newRecord.insertCell(4);
    cell6.innerHTML = `<button class = "btn btn-primary" type = "button" data-toggle = "modal" data-target = "#CRUDModal" onclick = "editRecord(this)">Edit</button>
    <button class = "btn btn-danger type = "button" onclick = "deleteRecord(this)">Delete</button>`
    document.forms[0].reset();
    //console.log(document.forms)
}

function deleteRecord() {
    console.log("Delete Button Was clicked.")
}

function editRecord(td) {
    console.log("Edit Request was generated." + td);
    selectedRow = td.parentElement.parentElement
    document.getElementById("firstName").value = selectedRow.cells[0].innerHTML
    document.getElementById("lastName").value = selectedRow.cells[1].innerHTML
    document.getElementById("email").value = selectedRow.cells[2].innerHTML
    document.getElementById("address").value = selectedRow.cells[3].innerHTML;

}

function updateRecord(formData) {
    selectedRow.cells[0].innerHTML = formData.firstName;
    selectedRow.cells[1].innerHTML = formData.email;
    selectedRow.cells[2].innerHTML = formData.salary;
    selectedRow.cells[3].innerHTML = formData.city;
}

function loaduser() {
    var x = localStorage.getItem("pastRecords");
    var x2 = JSON.parse(x)

    var index = 1;
    if (x2 != null) {
        for (index = 0; index < x2.length; index++) {
            console.log(x2)
            var table = document.getElementById("employeeList").getElementsByTagName('tbody')[0];
            var newRecord = table.insertRow(table.length);
            cell1 = newRecord.insertCell(0);
            cell1.innerHTML = x2[index].firstName;
            cell2 = newRecord.insertCell(1);
            cell2.innerHTML = x2[index].lastName
            cell3 = newRecord.insertCell(2);
            cell3.innerHTML = x2[index].email
            cell4 = newRecord.insertCell(3);
            cell4.innerHTML = x2[index].address
            cell6 = newRecord.insertCell(4);
            cell6.innerHTML = `<button class = "btn btn-primary" type = "button" data-toggle = "modal" data-target = "#CRUDModal" onclick = "editRecord(this)">Edit</button>
                            <button class = "btn btn-danger type = "button" onclick = "deleteRecord(this)" >Delete</button>`
            //document.forms[0].reset();
            //console.log(document.forms)
        }
        //localStorage.removeItem("pastRecords")
    }
} loaduser();